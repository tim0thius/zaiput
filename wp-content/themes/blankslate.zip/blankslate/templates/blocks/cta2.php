<section id="block-cta--<?= $cta_id ?> " class="block-cta" role="main" >
		<div class="grid__container">
			<img src="{{ get_field('cta_image')}}" alt="" class="block-cta__image">
			<p class="block-cta__content">{{ get_field('cta_content')}}</p>
		</div>
</section>