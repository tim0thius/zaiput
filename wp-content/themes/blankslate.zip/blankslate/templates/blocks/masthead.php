<div id="block-masthead">
	<?php the_post_thumbnail('full', ['class' => 'block-masthead--main-image', 'title' => 'Feature image']); ?>
</div>
